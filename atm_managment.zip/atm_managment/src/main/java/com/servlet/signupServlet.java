package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import org.hibernate.cfg.Configuration;
import org.hibernate.service.*;

import com.entity.account;


public class signupServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public signupServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    protected void service(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
	{

		
		// read configuration from .cfg.xml
		Configuration cfg = new Configuration();
		SessionFactory sf = cfg.configure("hibernate.cfg.xml").buildSessionFactory();
		
		// create a session
		
		Session S = sf.openSession();
			
		// begin a transaction
		S.getTransaction().begin();
				
		// fetch all control values into local variable
		String account_no=request.getParameter("acno");
		String password=request.getParameter("pswd");
		String password1=request.getParameter("pswd1");
		String name=request.getParameter("acnm");
		String fname=request.getParameter("fnm");
		String ad=request.getParameter("add");
		String pincode=request.getParameter("pin");
		String edu=request.getParameter("edu");
		String occ=request.getParameter("occ");
		String phn=request.getParameter("phn");
		String dob=request.getParameter("dob");
		int balance=0;
		if(password1.equals(password)) {
		// create account object and populate each state/variable/property with value
		
		account ln =new account();
//		
		ln.setAcno(account_no);
		ln.setNm(name);
		ln.setFnm(fname);
		ln.setAddress(ad);
		ln.setBalance(0);
		ln.setDob(dob);
		ln.setEdu(edu);
		ln.setOccupation(occ);
		ln.setPassword(password);
		ln.setPhone(phn);
		ln.setPin(pincode);
				
		S.save(ln);
		 HttpSession httpSession=request.getSession();
		    httpSession.setAttribute("message", "Account Saved");
		    response.sendRedirect("signup.jsp");
		
		S.getTransaction().commit();
		
		S.close();	
		}else
		{
			 HttpSession httpSession=request.getSession();
			    httpSession.setAttribute("message", "password mismatch!");
			    response.sendRedirect("signup.jsp");
		}
	}

}

	
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		
//		
//	}
//
//	
//	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		PrintWriter out=response.getWriter();
//		try {
//			String account_no=request.getParameter("acno");
//			String password=request.getParameter("pswd");
//			String name=request.getParameter("acnm");
//			String fname=request.getParameter("fnm");
//			String ad=request.getParameter("add");
//			String pincode=request.getParameter("pin");
//			String edu=request.getParameter("edu");
//			String occ=request.getParameter("occ");
//			String phn=request.getParameter("phn");
//			String dob=request.getParameter("dob");
//			int balance=0;
//			account ln =new account();
//			ln.setAcno(account_no);
//			ln.setNm(name);
//			ln.setFnm(fname);
//			ln.setAddress(ad);
//			ln.setBalance(0);
//			ln.setDob(dob);
//			ln.setEdu(edu);
//			ln.setOccupation(occ);
//			ln.setPassword(password);
//			ln.setPhone(phn);
//			ln.setPin(pincode);
//			
////			login ln=new login(account_no,password,name,fname,ad,pincode,edu,occ,phn,balance,dob);
//			boolean connection=false;
//			
//			Configuration con=new Configuration().configure().addAnnotatedClass(account.class);
//		
////			ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
//			SessionFactory sf=con.buildSessionFactory();
//			Session session =sf.openSession();
//			session.save(ln);
//			 HttpSession httpSession=request.getSession();
//		    httpSession.setAttribute("message", "Account Saved");
//		    response.sendRedirect("signup.jsp");
//			
////			
//		}catch(Exception e) {
//			e.printStackTrace();
//		}
//		doGet(request, response);
//		
//	}

//}





//Connection con;
//PreparedStatement pst;
//try {
//    Class.forName("com.mysql.jdbc.Driver");
//    // create connection
//
//    con = (Connection) DriverManager.getConnection("jdbc:mysql://locaLhost:3306/atm_process", "root", "");
//    pst = (PreparedStatement) con.prepareStatement("insert into account values (?,?,?,?,?,?,?,?,?,?,?)");
//    pst.setString(1,account_no);
//    pst.setString(2,name);
//    pst.setString(3,fname);
//    pst.setString(4,ad);
//    pst.setString(5, pincode);
//    pst.setString(6,edu);
//    pst.setString(7,occ);
//    pst.setString(8, phn);
//    pst.setString(9,dob);
//    pst.setInt(10,0);
//    pst.setString(11, password);
//    int row=pst.executeUpdate();
//    HttpSession httpSession=request.getSession();
//    httpSession.setAttribute("message", "Account Saved");
//    response.sendRedirect("signup.jsp");
// 
//    
//    con.close();
//} catch(Exception ex){
//    ex.printStackTrace();
//}
//