package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.transaction.Transaction;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.entity.account;

//import com.helper.factoryprovider;



public class loginformServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public loginformServlet() {
        super();
      
    }
    
    protected void service(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException
	{
    	 account ac = null;
		
		// read configuration from .cfg.xml
		Configuration cfg = new Configuration();
		SessionFactory sf = cfg.configure("hibernate.cfg.xml").buildSessionFactory();
		
		// create a session
		
		Session S = sf.openSession();
			
		// begin a transaction
		S.getTransaction().begin();
		String account_no=request.getParameter("acno");
		String password=request.getParameter("pswd");
		
		 ac = (account) S.createQuery("FROM account U WHERE U.acno = :acno").setParameter("acno", account_no)
	                .uniqueResult();
		 ac = (account) S.createQuery("FROM account U WHERE U.acno = :acno").setParameter("acno", account_no)
	                .uniqueResult();
		 if (ac.getAcno().equals(account_no) && ac.getPassword().equals(password)) {
          
			RequestDispatcher dispatcher=request.getRequestDispatcher("loginnext.jsp");
		dispatcher.forward(request, response);
		 HttpSession httpSession=request.getSession();
		httpSession.setAttribute("acno", account_no);
	    httpSession.setAttribute("acnm", ac.getNm());
	    httpSession.setAttribute("balance", ac.getBalance());
	    httpSession.setAttribute("fnm", ac.getFnm());
	    httpSession.setAttribute("phone", ac.getPhone());
		
		
		 }
		 else {
			 HttpSession httpSession=request.getSession();
			    httpSession.setAttribute("message", "wrong Account Number or Password");
			    response.sendRedirect("index.jsp");
			    
			   
		}
		
		 
		
		S.getTransaction().commit();
		
		S.close();		
	}

	

}	
	






















//Connection con;
//  PreparedStatement pst;
//  try {
//      Class.forName("com.mysql.jdbc.Driver");
//      // create connection
//
//      con = (Connection) DriverManager.getConnection("jdbc:mysql://locaLhost:3306/atm_process", "root", "");
//      pst = (PreparedStatement) con.prepareStatement("Select * from account where acno=? and password=? ");
//      pst.setString(1, account_no);
//      pst.setString(2, password);
//
//
//      ResultSet rs = pst.executeQuery();
//      if (rs.next()) {
//    	  connection=true;
////    HttpSession session=request.getSession();
////    session.setAttribute("username", account_no);
////    out.println("<script type=\"text/javascript\">");
////    out.println("alert('User or password incorrect');");
////    out.println("</script>");
////      out.println("alert('Login Successfull')");
////    HttpSession httpSession=request.getSession();
////    httpSession.setAttribute("message", ln.getNm());
//      response.sendRedirect("loginnext.jsp");
//      }
//      else {
////    	  HttpSession httpSession=request.getSession();
////          httpSession.setAttribute("message", "wrong Account Number or Password");
//    	  response.sendRedirect("index.jsp"); 
//      }
//      con.close();
//  } catch(Exception ex){
//      ex.printStackTrace();
//  }
//
