package com.entity;

import java.io.Serializable;

import javax.persistence.*;

@Entity
@Table(name="account")
public class account implements Serializable {
	
@Id
@Column(name="acno")
private String acno	;
@Column(name="nm")
private String nm	;
@Column(name="fnm")
private String fnm	;
@Column(name="address")
private String address;	
@Column(name="pin")
private String pin	;
@Column(name="edu")
private String edu	;
@Column(name="occupation")
private String occupation	;
@Column(name="phone")
private String phone	;
@Column(name="dob")
private String dob	;
@Column(name="balance")
private int balance	;
@Column(name="password")
private String password	;


public String getAcno() {
	return acno;
}
public void setAcno(String acno) {
	this.acno = acno;
}
public String getNm() {
	return nm;
}
public void setNm(String nm) {
	this.nm = nm;
}
public String getFnm() {
	return fnm;
}
public void setFnm(String fnm) {
	this.fnm = fnm;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getPin() {
	return pin;
}
public void setPin(String pin) {
	this.pin = pin;
}
public String getEdu() {
	return edu;
}
public void setEdu(String edu) {
	this.edu = edu;
}
public String getOccupation() {
	return occupation;
}
public void setOccupation(String occupation) {
	this.occupation = occupation;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public int getBalance() {
	return balance;
}
public void setBalance(int balance) {
	this.balance = balance;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public account(String acno, String nm, String fnm, String address, String pin, String edu, String occupation,
		String phone, String dob, int balance, String password) {
	super();
	this.acno = acno;
	this.nm = nm;
	this.fnm = fnm;
	this.address = address;
	this.pin = pin;
	this.edu = edu;
	this.occupation = occupation;
	this.phone = phone;
	this.dob = dob;
	this.balance = balance;
	this.password = password;
}
public account(String acno,  String password) {
	super();
	this.acno = acno;
	
	this.password = password;
}
public account() {
	super();
	
}

}
